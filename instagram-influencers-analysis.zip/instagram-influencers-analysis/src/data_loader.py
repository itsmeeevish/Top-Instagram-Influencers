import pandas as pd
import numpy as np
import yaml
import os

class DataLoader:
    def __init__(self, config_path='config.yaml'):
        with open(config_path, 'r') as file:
            self.config = yaml.safe_load(file)
        
    def load_raw_data(self):
        """Load raw Instagram influencers data"""
        try:
            df = pd.read_csv(self.config['data']['raw_path'])
            print(f"Data loaded successfully. Shape: {df.shape}")
            return df
        except FileNotFoundError:
            print("Raw data file not found. Please check the path.")
            return None
    
    def load_processed_data(self):
        """Load processed data if available"""
        try:
            df = pd.read_csv(self.config['data']['processed_path'])
            print(f"Processed data loaded. Shape: {df.shape}")
            return df
        except FileNotFoundError:
            print("Processed data not found. Loading raw data.")
            return self.load_raw_data()
    
    def get_data_info(self, df):
        """Get basic information about the dataset"""
        print("="*50)
        print("DATASET INFORMATION")
        print("="*50)
        print(f"Shape: {df.shape}")
        print(f"\nColumns: {list(df.columns)}")
        print(f"\nData Types:\n{df.dtypes}")
        print(f"\nMissing Values:\n{df.isnull().sum()}")
        print(f"\nFirst 5 rows:")
        return df.head()