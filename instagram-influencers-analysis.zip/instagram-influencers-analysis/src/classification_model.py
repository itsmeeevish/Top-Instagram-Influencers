import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import (accuracy_score, classification_report, 
                           confusion_matrix, f1_score)
import matplotlib.pyplot as plt
import seaborn as sns
import joblib

class ClassificationModel:
    def __init__(self, random_state=42, test_size=0.2):
        self.random_state = random_state
        self.test_size = test_size
        self.scaler = StandardScaler()
        self.model = None
        self.label_encoder = LabelEncoder()
        
    def prepare_data(self, X, y):
        """Prepare data for classification"""
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=self.test_size, random_state=self.random_state
        )
        
        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        return X_train_scaled, X_test_scaled, y_train, y_test
    
    def train_model(self, X_train, y_train, n_estimators=100):
        """Train Random Forest Classifier"""
        print("Training Random Forest Classifier...")
        
        self.model = RandomForestClassifier(
            n_estimators=n_estimators,
            random_state=self.random_state,
            n_jobs=-1,
            class_weight='balanced'
        )
        
        self.model.fit(X_train, y_train)
        return self.model
    
    def evaluate(self, X_test, y_test):
        """Evaluate classification model"""
        if self.model is None:
            raise ValueError("Model not trained. Call train_model() first.")
        
        y_pred = self.model.predict(X_test)
        
        accuracy = accuracy_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred, average='weighted')
        
        print("="*50)
        print("CLASSIFICATION MODEL EVALUATION")
        print("="*50)
        print(f"Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
        print(f"F1 Score: {f1:.4f}")
        print("\nClassification Report:")
        print(classification_report(y_test, y_pred))
        print("="*50)
        
        return {
            'accuracy': accuracy,
            'f1_score': f1,
            'y_pred': y_pred,
            'report': classification_report(y_test, y_pred, output_dict=True)
        }
    
    def plot_confusion_matrix(self, y_test, y_pred, figsize=(10, 8)):
        """Plot confusion matrix"""
        cm = confusion_matrix(y_test, y_pred)
        classes = sorted(np.unique(np.concatenate([y_test, y_pred])))
        
        plt.figure(figsize=figsize)
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                   xticklabels=classes, yticklabels=classes)
        plt.xlabel('Predicted Class')
        plt.ylabel('Actual Class')
        plt.title('Confusion Matrix of Engagement Rate Classification')
        plt.tight_layout()
        plt.show()
    
    def plot_class_distribution(self, y_test, y_pred, figsize=(12, 5)):
        """Plot actual vs predicted class distribution"""
        fig, axes = plt.subplots(1, 2, figsize=figsize)
        
        # Actual distribution
        sns.countplot(x=y_test, ax=axes[0], palette='viridis')
        axes[0].set_title('Actual Class Distribution')
        axes[0].set_xlabel('Engagement Rate Class')
        axes[0].set_ylabel('Count')
        
        # Predicted distribution
        sns.countplot(x=y_pred, ax=axes[1], palette='viridis')
        axes[1].set_title('Predicted Class Distribution')
        axes[1].set_xlabel('Engagement Rate Class')
        axes[1].set_ylabel('Count')
        
        plt.tight_layout()
        plt.show()
    
    def save_model(self, path='models/classification_model.pkl'):
        """Save trained model"""
        joblib.dump({
            'model': self.model,
            'scaler': self.scaler,
            'label_encoder': self.label_encoder
        }, path)
        print(f"Model saved to {path}")