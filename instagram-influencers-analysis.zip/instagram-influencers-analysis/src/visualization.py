import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np

class DataVisualizer:
    def __init__(self, style='seaborn'):
        plt.style.use(style)
        self.colors = ['#3498db', '#2ecc71', '#e74c3c', '#f39c12', '#9b59b6']
        
    def plot_followers_vs_engagement(self, df, figsize=(12, 6)):
        """Scatter plot of followers vs engagement rate"""
        plt.figure(figsize=figsize)
        scatter = sns.scatterplot(
            data=df, 
            x='followers', 
            y='60_day_eng_rate', 
            hue='country',
            alpha=0.7,
            palette='viridis'
        )
        plt.title('Followers vs 60-Day Engagement Rate', fontsize=14)
        plt.xlabel('Number of Followers (Millions)', fontsize=12)
        plt.ylabel('60-Day Engagement Rate (%)', fontsize=12)
        plt.legend(title='Country', bbox_to_anchor=(1.05, 1), loc='upper left')
        plt.tight_layout()
        plt.show()
    
    def plot_influence_score_distribution(self, df, figsize=(10, 5)):
        """Histogram of influence scores"""
        plt.figure(figsize=figsize)
        sns.histplot(df['influence_score'], bins=30, kde=True, color=self.colors[0])
        plt.title('Distribution of Influence Scores', fontsize=14)
        plt.xlabel('Influence Score', fontsize=12)
        plt.ylabel('Frequency', fontsize=12)
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()
    
    def plot_top_countries(self, df, top_n=10, figsize=(10, 5)):
        """Bar plot of top countries by influencer count"""
        top_countries = df['country'].value_counts().head(top_n)
        
        plt.figure(figsize=figsize)
        sns.barplot(x=top_countries.index, y=top_countries.values, palette='viridis')
        plt.title(f'Top {top_n} Countries by Number of Influencers', fontsize=14)
        plt.xlabel('Country', fontsize=12)
        plt.ylabel('Number of Influencers', fontsize=12)
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.show()
    
    def plot_correlation_matrix(self, df, figsize=(12, 8)):
        """Plot correlation matrix heatmap"""
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        correlation_matrix = df[numeric_cols].corr()
        
        plt.figure(figsize=figsize)
        sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', 
                   center=0, fmt='.2f', square=True)
        plt.title('Correlation Matrix of Instagram Influencer Metrics', fontsize=14)
        plt.tight_layout()
        plt.show()
    
    def plot_engagement_by_country(self, df, figsize=(12, 6)):
        """Box plot of engagement rates by country"""
        top_countries = df['country'].value_counts().head(10).index
        df_top = df[df['country'].isin(top_countries)]
        
        plt.figure(figsize=figsize)
        sns.boxplot(data=df_top, x='country', y='60_day_eng_rate', palette='viridis')
        plt.title('Engagement Rate Distribution by Country (Top 10)', fontsize=14)
        plt.xlabel('Country', fontsize=12)
        plt.ylabel('60-Day Engagement Rate (%)', fontsize=12)
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.show()