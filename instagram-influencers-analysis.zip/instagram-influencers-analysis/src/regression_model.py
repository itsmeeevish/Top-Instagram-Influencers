import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import matplotlib.pyplot as plt
import seaborn as sns
import joblib

class RegressionModel:
    def __init__(self, random_state=42, test_size=0.2):
        self.random_state = random_state
        self.test_size = test_size
        self.scaler = StandardScaler()
        self.model = None
        self.feature_importances = None
        
    def train_test_split(self, X, y):
        """Split data into training and testing sets"""
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=self.test_size, random_state=self.random_state
        )
        return X_train, X_test, y_train, y_test
    
    def scale_features(self, X_train, X_test):
        """Standardize features"""
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        return X_train_scaled, X_test_scaled
    
    def train_random_forest(self, X_train, y_train, n_estimators=100):
        """Train Random Forest Regressor"""
        print("Training Random Forest Regressor...")
        self.model = RandomForestRegressor(
            n_estimators=n_estimators,
            random_state=self.random_state,
            n_jobs=-1
        )
        self.model.fit(X_train, y_train)
        self.feature_importances = pd.Series(
            self.model.feature_importances_, 
            index=X_train.columns
        )
        return self.model
    
    def evaluate(self, X_test, y_test):
        """Evaluate model performance"""
        if self.model is None:
            raise ValueError("Model not trained. Call train_random_forest() first.")
        
        y_pred = self.model.predict(X_test)
        
        mse = mean_squared_error(y_test, y_pred)
        rmse = np.sqrt(mse)
        mae = mean_absolute_error(y_test, y_pred)
        r2 = r2_score(y_test, y_pred)
        
        print("="*50)
        print("MODEL EVALUATION")
        print("="*50)
        print(f"Mean Squared Error: {mse:.4f}")
        print(f"Root Mean Squared Error: {rmse:.4f}")
        print(f"Mean Absolute Error: {mae:.4f}")
        print(f"R^2 Score: {r2:.4f}")
        print("="*50)
        
        return {
            'mse': mse,
            'rmse': rmse,
            'mae': mae,
            'r2': r2,
            'y_pred': y_pred
        }
    
    def plot_feature_importance(self, figsize=(10, 6)):
        """Plot feature importance"""
        if self.feature_importances is None:
            raise ValueError("Feature importances not available. Train model first.")
        
        plt.figure(figsize=figsize)
        self.feature_importances.sort_values().plot(kind='barh')
        plt.title('Feature Importance in Random Forest Model')
        plt.xlabel('Importance Score')
        plt.tight_layout()
        plt.show()
    
    def plot_predictions_vs_actual(self, y_test, y_pred, figsize=(10, 6)):
        """Plot predicted vs actual values"""
        plt.figure(figsize=figsize)
        plt.scatter(y_test, y_pred, alpha=0.6)
        plt.plot([y_test.min(), y_test.max()], 
                 [y_test.min(), y_test.max()], 'r--', lw=2)
        plt.xlabel('True Influence Score')
        plt.ylabel('Predicted Influence Score')
        plt.title('True vs Predicted Influence Score')
        plt.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.show()
    
    def save_model(self, path='models/random_forest_model.pkl'):
        """Save trained model"""
        joblib.dump(self.model, path)
        joblib.dump(self.scaler, 'models/scaler.pkl')
        print(f"Model saved to {path}")
    
    def load_model(self, model_path='models/random_forest_model.pkl', 
                   scaler_path='models/scaler.pkl'):
        """Load trained model"""
        self.model = joblib.load(model_path)
        self.scaler = joblib.load(scaler_path)
        print("Model loaded successfully")