"""
Feature Engineering for Instagram Influencers Data
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder

class FeatureEngineer:
    def __init__(self):
        pass
    
    def create_engagement_classes(self, df):
        """Create engagement rate classes as per document page 59-60"""
        # Create bins exactly as document page 59
        bins = [0, 1, 3, df['60_day_eng_rate'].max()]
        labels = ['Low', 'Medium', 'High']
        
        df['engagement_rate_class'] = pd.cut(df['60_day_eng_rate'], 
                                             bins=bins, 
                                             labels=labels,
                                             include_lowest=True)
        return df
    
    def create_features(self, df):
        """Create new features as per document page 6"""
        print("Creating new features...")
        
        # Create engagement-related features (EXACT from document page 6)
        df['like_follower_ratio'] = df['total_likes'] / df['followers']
        df['post_follower_ratio'] = df['posts'] / df['followers']
        df['avg_likes_ratio'] = df['avg_likes'] / df['followers']
        
        print(f"Created 3 new features")
        return df
    
    def prepare_regression_features(self, df):
        """Prepare features for regression model as per document page 7"""
        # EXACT features from document page 7
        features = ['followers', 'avg_likes', '60_day_eng_rate', 
                   'new_post_avg_like', 'like_follower_ratio', 
                   'post_follower_ratio']
        
        # Select only existing columns
        available_features = [f for f in features if f in df.columns]
        
        X = df[available_features]
        y = df['influence_score']
        
        print(f"Regression features: {available_features}")
        return X, y
    
    def prepare_classification_features(self, df):
        """Prepare features for classification model"""
        # Encode country
        encoder = LabelEncoder()
        
        # Handle missing countries
        df['country_filled'] = df['country'].fillna('Unknown')
        df['country_encoded'] = encoder.fit_transform(df['country_filled'])
        
        # Features as used in document
        features = ['followers', 'influence_score', 'country_encoded']
        X = df[features]
        
        # Check if engagement_rate_class exists, if not create it
        if 'engagement_rate_class' not in df.columns:
            df = self.create_engagement_classes(df)
        
        y = df['engagement_rate_class']
        
        print(f"Classification features: {features}")
        return X, y, df
    
    def get_feature_statistics(self, df):
        """Get statistics for created features"""
        new_features = ['like_follower_ratio', 'post_follower_ratio', 'avg_likes_ratio']
        
        if all(feature in df.columns for feature in new_features):
            print("\nNew Features Statistics:")
            print(df[new_features].describe())
            
            # Correlation with influence_score
            print("\nCorrelation with Influence Score:")
            correlations = df[new_features + ['influence_score']].corr()['influence_score']
            print(correlations.drop('influence_score'))
        
        return df