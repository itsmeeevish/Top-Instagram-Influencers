import pandas as pd
import numpy as np

class DataCleaner:
    def __init__(self):
        self.unit_conversion = {
            'b': 'e9', 'B': 'e9',  # Billion
            'm': 'e6', 'M': 'e6',  # Million
            'k': 'e3', 'K': 'e3',  # Thousand
            '%': ''                # Remove percentage
        }
    
    def clean_document_data(self, df):
        """Clean data EXACTLY as shown in document"""
        print("Cleaning Instagram Influencers Data...")
        
        # Make a copy
        df_clean = df.copy()
        
        # Convert units EXACTLY as document page 29-30
        columns_to_convert = ['total_likes', 'posts', 'followers', 
                             'avg_likes', '60_day_eng_rate', 'new_post_avg_like']
        
        # Apply conversion for each column
        for col in columns_to_convert:
            if col in df_clean.columns:
                # Convert to string, then replace units
                df_clean[col] = df_clean[col].astype(str)
                for unit, replacement in self.unit_conversion.items():
                    df_clean[col] = df_clean[col].str.replace(unit, replacement, regex=False)
                
                # Convert to numeric
                df_clean[col] = pd.to_numeric(df_clean[col], errors='coerce')
        
        # Handle specific conversions from document
        # Convert influence_score to int
        if 'influence_score' in df_clean.columns:
            df_clean['influence_score'] = pd.to_numeric(df_clean['influence_score'], errors='coerce').astype('Int64')
        
        # Convert rank to int
        if 'rank' in df_clean.columns:
            df_clean['rank'] = pd.to_numeric(df_clean['rank'], errors='coerce').astype('Int64')
        
        # Handle country missing values (document page 42)
        if 'country' in df_clean.columns:
            df_clean['country'].fillna('Unknown', inplace=True)
        
        print("Data cleaning completed!")
        return df_clean
    
    def create_features_document(self, df):
        """Create features EXACTLY as document page 6"""
        df_features = df.copy()
        
        # EXACT features from document page 6
        df_features['like_follower_ratio'] = df_features['total_likes'] / df_features['followers']
        df_features['post_follower_ratio'] = df_features['posts'] / df_features['followers']
        df_features['avg_likes_ratio'] = df_features['avg_likes'] / df_features['followers']
        
        return df_features