"""
Instagram Influencers Analysis - FIXED LAYOUT VERSION
No overlapping, clean Power BI style dashboard
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.gridspec import GridSpec
import os
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("📊 INSTAGRAM INFLUENCERS ANALYSIS - CLEAN DASHBOARD")
print("="*80)

# ============================================================================
# 1. SETUP AND DATA LOADING
# ============================================================================
print("\n" + "="*60)
print("1. SETUP AND DATA LOADING")
print("="*60)

# Create output directories
os.makedirs("visualizations", exist_ok=True)
os.makedirs("reports", exist_ok=True)

# Load your data
DATA_FILE = "data/top_insta_influencers_data.csv"

if not os.path.exists(DATA_FILE):
    print(f"❌ ERROR: File not found: {DATA_FILE}")
    exit()

try:
    df = pd.read_csv(DATA_FILE)
    print(f"✓ Data loaded: {len(df)} rows, {len(df.columns)} columns")
except Exception as e:
    print(f"❌ Error loading data: {e}")
    exit()

# ============================================================================
# 2. DATA CLEANING
# ============================================================================
print("\n2. DATA CLEANING")

def clean_data(df):
    df_clean = df.copy()
    
    # Remove duplicates
    df_clean.drop_duplicates(inplace=True)
    
    # Handle missing values
    for col in df_clean.columns:
        if df_clean[col].isnull().sum() > 0:
            if df_clean[col].dtype == 'object':
                df_clean[col].fillna('Unknown', inplace=True)
            else:
                df_clean[col].fillna(df_clean[col].median(), inplace=True)
    
    # Convert units
    if 'followers' in df_clean.columns:
        sample = str(df_clean['followers'].iloc[0])
        if any(unit in sample.lower() for unit in ['m', 'k', 'b', '%']):
            replace_dict = {'b': 'e9', 'm': 'e6', 'k': 'e3', '%': ''}
            cols_to_convert = ['posts', 'followers', 'avg_likes', '60_day_eng_rate', 'new_post_avg_like', 'total_likes']
            
            for col in cols_to_convert:
                if col in df_clean.columns:
                    try:
                        df_clean[col] = df_clean[col].astype(str)
                        for unit, replacement in replace_dict.items():
                            df_clean[col] = df_clean[col].str.replace(unit, replacement, regex=False)
                        df_clean[col] = pd.to_numeric(df_clean[col], errors='coerce')
                    except:
                        continue
    
    return df_clean

df_clean = clean_data(df)
print("✓ Data cleaning completed")

# ============================================================================
# 3. CREATE SEPARATE VISUALIZATIONS (NO OVERLAP)
# ============================================================================
print("\n" + "="*60)
print("3. CREATING SEPARATE VISUALIZATIONS")
print("="*60)

# Set style
plt.style.use('default')
sns.set_style("whitegrid")

# ============================================================================
# VISUALIZATION 1: KEY METRICS DASHBOARD
# ============================================================================
print("Creating Visualization 1: Key Metrics Dashboard...")

fig1 = plt.figure(figsize=(16, 10))
fig1.suptitle('Instagram Influencers - Key Metrics Dashboard', fontsize=20, fontweight='bold', y=0.95)

# Create a 3x3 grid with MORE SPACE
gs1 = GridSpec(3, 3, figure=fig1, hspace=0.4, wspace=0.4, left=0.08, right=0.95, top=0.9, bottom=0.1)

# 1.1 Key Metrics Box
ax1 = fig1.add_subplot(gs1[0, 0])
ax1.axis('off')
ax1.set_title('📊 KEY METRICS', fontsize=14, fontweight='bold', pad=15)

# Calculate metrics
metrics = [
    f"Total Influencers\n{len(df_clean):,}",
    f"Avg Followers\n{df_clean['followers'].mean():,.0f}" if 'followers' in df_clean.columns else "Avg Followers\nN/A",
    f"Avg Engagement\n{df_clean['60_day_eng_rate'].mean():.2f}%" if '60_day_eng_rate' in df_clean.columns else "Avg Engagement\nN/A",
    f"Avg Influence Score\n{df_clean['influence_score'].mean():.1f}" if 'influence_score' in df_clean.columns else "Avg Influence\nN/A"
]

# Create metric boxes
for i, metric in enumerate(metrics):
    y_pos = 0.8 - i * 0.2
    ax1.text(0.5, y_pos, metric, fontsize=11, fontweight='bold', 
             ha='center', va='center', 
             bbox=dict(boxstyle='round', facecolor='lightblue', alpha=0.7, pad=1))

# 1.2 Followers vs Engagement
ax2 = fig1.add_subplot(gs1[0, 1:])
if 'followers' in df_clean.columns and '60_day_eng_rate' in df_clean.columns:
    scatter = ax2.scatter(df_clean['followers'], df_clean['60_day_eng_rate'], 
                         alpha=0.6, s=40, c='blue')
    ax2.set_xlabel('Followers', fontsize=11)
    ax2.set_ylabel('Engagement Rate (%)', fontsize=11)
    ax2.set_xscale('log')
    ax2.grid(True, alpha=0.3)
    ax2.set_title('Followers vs Engagement Rate', fontsize=13, fontweight='bold')

# 1.3 Influence Score Distribution
ax3 = fig1.add_subplot(gs1[1, 0])
if 'influence_score' in df_clean.columns:
    ax3.hist(df_clean['influence_score'], bins=15, color='skyblue', edgecolor='black', alpha=0.7)
    ax3.axvline(df_clean['influence_score'].mean(), color='red', linestyle='--', linewidth=2)
    ax3.set_xlabel('Influence Score', fontsize=11)
    ax3.set_ylabel('Count', fontsize=11)
    ax3.set_title('Influence Score Distribution', fontsize=13, fontweight='bold')
    ax3.grid(True, alpha=0.3)

# 1.4 Top Countries
ax4 = fig1.add_subplot(gs1[1, 1])
if 'country' in df_clean.columns:
    top_countries = df_clean['country'].value_counts().head(8)
    bars = ax4.barh(range(len(top_countries)), top_countries.values, color='lightgreen')
    ax4.set_yticks(range(len(top_countries)))
    ax4.set_yticklabels(top_countries.index, fontsize=9)
    ax4.set_xlabel('Count', fontsize=11)
    ax4.set_title('Top Countries', fontsize=13, fontweight='bold')
    
    for i, v in enumerate(top_countries.values):
        ax4.text(v + 0.5, i, str(v), va='center', fontsize=9)

# 1.5 Engagement by Country
ax5 = fig1.add_subplot(gs1[1, 2])
if 'country' in df_clean.columns and '60_day_eng_rate' in df_clean.columns:
    top_5_countries = df_clean['country'].value_counts().head(5).index
    df_top = df_clean[df_clean['country'].isin(top_5_countries)]
    
    engagement_means = df_top.groupby('country')['60_day_eng_rate'].mean().sort_values()
    engagement_means.plot(kind='barh', ax=ax5, color='orange', alpha=0.7)
    ax5.set_xlabel('Avg Engagement Rate', fontsize=11)
    ax5.set_title('Engagement by Country', fontsize=13, fontweight='bold')

# 1.6 Correlation Heatmap
ax6 = fig1.add_subplot(gs1[2, :])
numeric_cols = df_clean.select_dtypes(include=[np.number]).columns
if len(numeric_cols) > 1:
    corr_matrix = df_clean[numeric_cols].corr()
    im = ax6.imshow(corr_matrix, cmap='coolwarm', aspect='auto')
    ax6.set_xticks(range(len(corr_matrix.columns)))
    ax6.set_yticks(range(len(corr_matrix.columns)))
    ax6.set_xticklabels(corr_matrix.columns, rotation=45, ha='right', fontsize=9)
    ax6.set_yticklabels(corr_matrix.columns, fontsize=9)
    ax6.set_title('Correlation Matrix', fontsize=13, fontweight='bold')
    
    # Add values
    for i in range(len(corr_matrix)):
        for j in range(len(corr_matrix)):
            ax6.text(j, i, f'{corr_matrix.iloc[i, j]:.2f}', ha='center', va='center', color='black', fontsize=8)

plt.tight_layout(rect=[0, 0, 1, 0.95])
plt.savefig("visualizations/dashboard_main.png", dpi=150, bbox_inches='tight')
print("✓ Saved: visualizations/dashboard_main.png")
plt.show()

# ============================================================================
# VISUALIZATION 2: ENGAGEMENT ANALYSIS
# ============================================================================
print("\nCreating Visualization 2: Engagement Analysis...")

fig2, axes2 = plt.subplots(2, 2, figsize=(14, 10))
fig2.suptitle('Engagement Rate Analysis', fontsize=18, fontweight='bold', y=0.95)

# 2.1 Engagement Distribution
ax1 = axes2[0, 0]
if '60_day_eng_rate' in df_clean.columns:
    ax1.hist(df_clean['60_day_eng_rate'], bins=20, color='lightcoral', edgecolor='black', alpha=0.7)
    ax1.axvline(df_clean['60_day_eng_rate'].mean(), color='red', linestyle='--', linewidth=2)
    ax1.set_xlabel('Engagement Rate (%)', fontsize=11)
    ax1.set_ylabel('Count', fontsize=11)
    ax1.set_title('Engagement Rate Distribution', fontsize=13, fontweight='bold')
    ax1.grid(True, alpha=0.3)

# 2.2 Box Plot by Follower Categories
ax2 = axes2[0, 1]
if 'followers' in df_clean.columns and '60_day_eng_rate' in df_clean.columns:
    # Create follower categories
    df_clean['follower_category'] = pd.cut(df_clean['followers'], 
                                          bins=[0, 1e6, 1e7, 1e8, df_clean['followers'].max()],
                                          labels=['<1M', '1M-10M', '10M-100M', '>100M'])
    
    categories = ['<1M', '1M-10M', '10M-100M', '>100M']
    data = [df_clean[df_clean['follower_category'] == cat]['60_day_eng_rate'].dropna() 
            for cat in categories if cat in df_clean['follower_category'].unique()]
    
    if data:
        bp = ax2.boxplot(data, labels=categories[:len(data)], patch_artist=True)
        for patch in bp['boxes']:
            patch.set_facecolor('lightblue')
        ax2.set_xlabel('Follower Category', fontsize=11)
        ax2.set_ylabel('Engagement Rate (%)', fontsize=11)
        ax2.set_title('Engagement by Follower Size', fontsize=13, fontweight='bold')
        ax2.grid(True, alpha=0.3, axis='y')

# 2.3 Scatter: Followers vs Engagement (colored by influence)
ax3 = axes2[1, 0]
if all(col in df_clean.columns for col in ['followers', '60_day_eng_rate', 'influence_score']):
    scatter = ax3.scatter(df_clean['followers'], df_clean['60_day_eng_rate'], 
                         c=df_clean['influence_score'], cmap='viridis', alpha=0.6, s=50)
    ax3.set_xlabel('Followers', fontsize=11)
    ax3.set_ylabel('Engagement Rate (%)', fontsize=11)
    ax3.set_xscale('log')
    ax3.set_title('Engagement vs Followers (colored by Influence)', fontsize=13, fontweight='bold')
    ax3.grid(True, alpha=0.3)
    plt.colorbar(scatter, ax=ax3, label='Influence Score')

# 2.4 Top 10 by Engagement
ax4 = axes2[1, 1]
if all(col in df_clean.columns for col in ['channel_info', '60_day_eng_rate']):
    top_engagement = df_clean.nlargest(10, '60_day_eng_rate')[['channel_info', '60_day_eng_rate']]
    bars = ax4.barh(range(len(top_engagement)), top_engagement['60_day_eng_rate'], color='lightgreen')
    ax4.set_yticks(range(len(top_engagement)))
    ax4.set_yticklabels(top_engagement['channel_info'], fontsize=9)
    ax4.set_xlabel('Engagement Rate (%)', fontsize=11)
    ax4.set_title('Top 10 by Engagement Rate', fontsize=13, fontweight='bold')
    
    for i, v in enumerate(top_engagement['60_day_eng_rate']):
        ax4.text(v + 0.1, i, f'{v:.2f}%', va='center', fontsize=9)

plt.tight_layout(rect=[0, 0, 1, 0.95])
plt.savefig("visualizations/engagement_analysis.png", dpi=150, bbox_inches='tight')
print("✓ Saved: visualizations/engagement_analysis.png")
plt.show()

# ============================================================================
# VISUALIZATION 3: INFLUENCER PERFORMANCE
# ============================================================================
print("\nCreating Visualization 3: Influencer Performance...")

fig3, axes3 = plt.subplots(2, 2, figsize=(14, 10))
fig3.suptitle('Influencer Performance Metrics', fontsize=18, fontweight='bold', y=0.95)

# 3.1 Top 10 Influencers
ax1 = axes3[0, 0]
if all(col in df_clean.columns for col in ['channel_info', 'influence_score']):
    top_influencers = df_clean.nlargest(10, 'influence_score')[['channel_info', 'influence_score', 'followers']]
    x = range(len(top_influencers))
    width = 0.35
    
    bars1 = ax1.bar([i - width/2 for i in x], top_influencers['influence_score'], width, 
                   label='Influence Score', alpha=0.7, color='skyblue')
    ax1_twin = ax1.twinx()
    bars2 = ax1_twin.bar([i + width/2 for i in x], top_influencers['followers'], width,
                        label='Followers', alpha=0.7, color='lightcoral')
    
    ax1.set_xticks(x)
    ax1.set_xticklabels(top_influencers['channel_info'], rotation=45, ha='right', fontsize=9)
    ax1.set_ylabel('Influence Score', fontsize=11)
    ax1_twin.set_ylabel('Followers', fontsize=11)
    ax1.set_title('Top 10 Influencers', fontsize=13, fontweight='bold')
    
    # Combine legends
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax1_twin.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper right')

# 3.2 Posts Analysis
ax2 = axes3[0, 1]
if 'posts' in df_clean.columns:
    ax2.hist(df_clean['posts'], bins=20, color='orange', edgecolor='black', alpha=0.7)
    ax2.axvline(df_clean['posts'].mean(), color='red', linestyle='--', linewidth=2)
    ax2.set_xlabel('Number of Posts', fontsize=11)
    ax2.set_ylabel('Count', fontsize=11)
    ax2.set_title('Posts Distribution', fontsize=13, fontweight='bold')
    ax2.grid(True, alpha=0.3)

# 3.3 Likes Analysis
ax3 = axes3[1, 0]
if all(col in df_clean.columns for col in ['avg_likes', 'new_post_avg_like']):
    # Sample for clarity
    sample_size = min(20, len(df_clean))
    sample_df = df_clean.sample(sample_size, random_state=42)
    
    x = range(sample_size)
    width = 0.35
    
    ax3.bar([i - width/2 for i in x], sample_df['avg_likes'], width,
           label='Avg Likes', alpha=0.7, color='lightgreen')
    ax3.bar([i + width/2 for i in x], sample_df['new_post_avg_like'], width,
           label='New Post Likes', alpha=0.7, color='purple')
    
    ax3.set_xlabel('Influencer Sample', fontsize=11)
    ax3.set_ylabel('Likes', fontsize=11)
    ax3.set_title('Likes Comparison (Sample)', fontsize=13, fontweight='bold')
    ax3.legend()
    ax3.set_xticks(x)
    ax3.set_xticklabels([f'Inf{i+1}' for i in range(sample_size)], rotation=45, fontsize=8)

# 3.4 Country Performance
ax4 = axes3[1, 1]
if 'country' in df_clean.columns:
    country_perf = df_clean.groupby('country').agg({
        'influence_score': 'mean',
        '60_day_eng_rate': 'mean',
        'followers': 'mean'
    }).nlargest(8, 'influence_score')
    
    x = range(len(country_perf))
    width = 0.25
    
    ax4.bar([i - width for i in x], country_perf['influence_score'], width,
           label='Influence Score', alpha=0.7, color='blue')
    ax4.bar(x, country_perf['60_day_eng_rate'], width,
           label='Engagement Rate', alpha=0.7, color='red')
    ax4_twin = ax4.twinx()
    ax4_twin.bar([i + width for i in x], country_perf['followers'], width,
                label='Avg Followers', alpha=0.7, color='green')
    
    ax4.set_xticks(x)
    ax4.set_xticklabels(country_perf.index, rotation=45, ha='right', fontsize=9)
    ax4.set_ylabel('Score/Rate', fontsize=11)
    ax4_twin.set_ylabel('Followers', fontsize=11)
    ax4.set_title('Top Countries Performance', fontsize=13, fontweight='bold')
    
    # Combine legends
    lines1, labels1 = ax4.get_legend_handles_labels()
    lines2, labels2 = ax4_twin.get_legend_handles_labels()
    ax4.legend(lines1 + lines2, labels1 + labels2, loc='upper right')

plt.tight_layout(rect=[0, 0, 1, 0.95])
plt.savefig("visualizations/performance_metrics.png", dpi=150, bbox_inches='tight')
print("✓ Saved: visualizations/performance_metrics.png")
plt.show()

# ============================================================================
# VISUALIZATION 4: SUMMARY STATISTICS
# ============================================================================
print("\nCreating Visualization 4: Summary Statistics...")

fig4 = plt.figure(figsize=(12, 8))
fig4.suptitle('Summary Statistics', fontsize=18, fontweight='bold', y=0.95)

# Create statistics table
stats_data = []
stats_columns = ['Metric', 'Mean', 'Median', 'Min', 'Max', 'Std Dev']

if 'influence_score' in df_clean.columns:
    stats_data.append(['Influence Score', 
                      f"{df_clean['influence_score'].mean():.2f}",
                      f"{df_clean['influence_score'].median():.2f}",
                      f"{df_clean['influence_score'].min():.2f}",
                      f"{df_clean['influence_score'].max():.2f}",
                      f"{df_clean['influence_score'].std():.2f}"])

if 'followers' in df_clean.columns:
    stats_data.append(['Followers', 
                      f"{df_clean['followers'].mean():,.0f}",
                      f"{df_clean['followers'].median():,.0f}",
                      f"{df_clean['followers'].min():,.0f}",
                      f"{df_clean['followers'].max():,.0f}",
                      f"{df_clean['followers'].std():,.0f}"])

if '60_day_eng_rate' in df_clean.columns:
    stats_data.append(['Engagement Rate', 
                      f"{df_clean['60_day_eng_rate'].mean():.2f}%",
                      f"{df_clean['60_day_eng_rate'].median():.2f}%",
                      f"{df_clean['60_day_eng_rate'].min():.2f}%",
                      f"{df_clean['60_day_eng_rate'].max():.2f}%",
                      f"{df_clean['60_day_eng_rate'].std():.2f}"])

if 'posts' in df_clean.columns:
    stats_data.append(['Posts', 
                      f"{df_clean['posts'].mean():,.0f}",
                      f"{df_clean['posts'].median():,.0f}",
                      f"{df_clean['posts'].min():,.0f}",
                      f"{df_clean['posts'].max():,.0f}",
                      f"{df_clean['posts'].std():,.0f}"])

ax = fig4.add_subplot(111)
ax.axis('tight')
ax.axis('off')

# Create table
table = ax.table(cellText=stats_data, colLabels=stats_columns, loc='center', cellLoc='center')
table.auto_set_font_size(False)
table.set_fontsize(10)
table.scale(1.2, 1.5)

# Style header
for i in range(len(stats_columns)):
    table[0, i].set_facecolor('#2E86AB')
    table[0, i].set_text_props(weight='bold', color='white')

# Alternate row colors
for i in range(1, len(stats_data) + 1):
    color = '#F5F5F5' if i % 2 == 0 else '#FFFFFF'
    for j in range(len(stats_columns)):
        table[i, j].set_facecolor(color)

plt.tight_layout(rect=[0, 0, 1, 0.95])
plt.savefig("visualizations/summary_statistics.png", dpi=150, bbox_inches='tight')
print("✓ Saved: visualizations/summary_statistics.png")
plt.show()

# ============================================================================
# 4. CREATE REPORTS
# ============================================================================
print("\n" + "="*60)
print("4. CREATING REPORTS")
print("="*60)

# Create report
report_content = f"""
{'='*80}
INSTAGRAM INFLUENCERS ANALYSIS REPORT
{'='*80}

Generated: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}
Data Source: {DATA_FILE}
Total Records: {len(df_clean):,}

SUMMARY
{'='*50}
This analysis examines {len(df_clean):,} Instagram influencers to identify 
key patterns and performance metrics for influencer marketing.

KEY FINDINGS
{'='*50}
1. Average follower count: {df_clean['followers'].mean():,.0f if 'followers' in df_clean.columns else 'N/A'}
2. Average engagement rate: {df_clean['60_day_eng_rate'].mean():.2f}%' if '60_day_eng_rate' in df_clean.columns else 'N/A'
3. Average influence score: {df_clean['influence_score'].mean():.1f if 'influence_score' in df_clean.columns else 'N/A'}
4. Countries analyzed: {df_clean['country'].nunique() if 'country' in df_clean.columns else 'N/A'}

TOP PERFORMERS
{'='*50}
"""

# Add top influencers
if all(col in df_clean.columns for col in ['channel_info', 'influence_score']):
    top_5 = df_clean.nlargest(5, 'influence_score')
    for i, (_, row) in enumerate(top_5.iterrows(), 1):
        report_content += f"{i}. {row['channel_info']} - Score: {row['influence_score']:.1f}\n"

report_content += f"""
RECOMMENDATIONS
{'='*50}
1. Focus on influencers with 1M-10M followers for optimal engagement
2. Consider country-specific strategies based on engagement patterns
3. Monitor new post performance for growth indicators
4. Use influence score as a key metric for partnerships

VISUALIZATIONS CREATED
{'='*50}
1. dashboard_main.png - Main dashboard with key metrics
2. engagement_analysis.png - Detailed engagement analysis
3. performance_metrics.png - Influencer performance metrics
4. summary_statistics.png - Statistical summary table

All visualizations are saved in the 'visualizations/' folder.

{'='*80}
ANALYSIS COMPLETED
{'='*80}
"""

# Save report
report_file = "reports/analysis_report.txt"
with open(report_file, 'w', encoding='utf-8') as f:
    f.write(report_content)

print(f"✓ Report saved: {report_file}")

# ============================================================================
# FINAL OUTPUT
# ============================================================================
print("\n" + "="*80)
print("✅ ANALYSIS COMPLETED SUCCESSFULLY!")
print("="*80)

print(f"""
📊 VISUALIZATIONS CREATED (NO OVERLAP):
   1. visualizations/dashboard_main.png
   2. visualizations/engagement_analysis.png
   3. visualizations/performance_metrics.png
   4. visualizations/summary_statistics.png

📋 REPORTS:
   • reports/analysis_report.txt

🎯 NEXT STEPS:
   1. Open the visualizations in 'visualizations/' folder
   2. Each visualization is clean and non-overlapping
   3. Share with stakeholders

All files saved successfully!
""")