-- Instagram Influencers Advanced Analysis Queries
-- Based on document data format and structure

-- =============================================
-- 1. INFLUENCE SCORE ANALYSIS
-- =============================================

-- 1.1 Categorize influencers by influence score
SELECT 
    CASE 
        WHEN influence_score >= 90 THEN 'Top Tier (90+)'
        WHEN influence_score >= 80 THEN 'High Tier (80-89)'
        WHEN influence_score >= 70 THEN 'Mid Tier (70-79)'
        ELSE 'Lower Tier (<70)'
    END as score_category,
    COUNT(*) as influencer_count,
    ROUND(AVG(CAST(REPLACE(REPLACE(followers, 'm', ''), 'b', '') AS DECIMAL)), 1) as avg_followers_millions,
    ROUND(AVG(CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL)), 2) as avg_engagement_rate
FROM influencers
GROUP BY score_category
ORDER BY 
    CASE score_category
        WHEN 'Top Tier (90+)' THEN 1
        WHEN 'High Tier (80-89)' THEN 2
        WHEN 'Mid Tier (70-79)' THEN 3
        ELSE 4
    END;

-- =============================================
-- 2. ENGAGEMENT RATE ANALYSIS
-- =============================================

-- 2.1 Engagement rate distribution
SELECT 
    CASE 
        WHEN CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL) >= 5 THEN 'Very High (5%+)'
        WHEN CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL) >= 3 THEN 'High (3-5%)'
        WHEN CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL) >= 1 THEN 'Medium (1-3%)'
        ELSE 'Low (<1%)'
    END as engagement_category,
    COUNT(*) as influencer_count,
    ROUND(AVG(influence_score), 2) as avg_influence_score,
    ROUND(AVG(CAST(REPLACE(REPLACE(followers, 'm', ''), 'b', '') AS DECIMAL)), 1) as avg_followers_millions
FROM influencers
GROUP BY engagement_category
ORDER BY 
    CASE engagement_category
        WHEN 'Very High (5%+)' THEN 1
        WHEN 'High (3-5%)' THEN 2
        WHEN 'Medium (1-3%)' THEN 3
        ELSE 4
    END;

-- =============================================
-- 3. FOLLOWER SIZE ANALYSIS
-- =============================================

-- 3.1 Influencers by follower size
SELECT 
    CASE 
        WHEN followers LIKE '%b%' OR CAST(REPLACE(REPLACE(followers, 'm', ''), 'b', '') AS DECIMAL) >= 100 THEN 'Mega (>100M)'
        WHEN followers LIKE '%m%' THEN 
            CASE 
                WHEN CAST(REPLACE(followers, 'm', '') AS DECIMAL) >= 50 THEN 'Large (50-100M)'
                WHEN CAST(REPLACE(followers, 'm', '') AS DECIMAL) >= 10 THEN 'Medium (10-50M)'
                ELSE 'Small (1-10M)'
            END
        ELSE 'Micro (<1M)'
    END as follower_size,
    COUNT(*) as influencer_count,
    ROUND(AVG(influence_score), 2) as avg_influence_score,
    ROUND(AVG(CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL)), 2) as avg_engagement_rate
FROM influencers
GROUP BY follower_size
ORDER BY 
    CASE follower_size
        WHEN 'Mega (>100M)' THEN 1
        WHEN 'Large (50-100M)' THEN 2
        WHEN 'Medium (10-50M)' THEN 3
        WHEN 'Small (1-10M)' THEN 4
        ELSE 5
    END;

-- =============================================
-- 4. COUNTRY PERFORMANCE ANALYSIS
-- =============================================

-- 4.1 Top performing countries
WITH country_stats AS (
    SELECT 
        country,
        COUNT(*) as influencer_count,
        ROUND(AVG(influence_score), 2) as avg_influence_score,
        ROUND(AVG(CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL)), 3) as avg_engagement_rate,
        ROUND(SUM(
            CASE 
                WHEN followers LIKE '%b%' THEN CAST(REPLACE(followers, 'b', '') AS DECIMAL) * 1000
                WHEN followers LIKE '%m%' THEN CAST(REPLACE(followers, 'm', '') AS DECIMAL)
                ELSE CAST(followers AS DECIMAL) / 1000000
            END
        ), 0) as total_followers_millions
    FROM influencers
    WHERE country IS NOT NULL AND country != 'NaN'
    GROUP BY country
    HAVING COUNT(*) >= 2
)
SELECT 
    country,
    influencer_count,
    avg_influence_score,
    RANK() OVER (ORDER BY avg_influence_score DESC) as influence_rank,
    avg_engagement_rate,
    RANK() OVER (ORDER BY avg_engagement_rate DESC) as engagement_rank,
    total_followers_millions
FROM country_stats
ORDER BY avg_influence_score DESC
LIMIT 10;

-- =============================================
-- 5. POSTING FREQUENCY ANALYSIS
-- =============================================

-- 5.1 Posts analysis
SELECT 
    CASE 
        WHEN posts LIKE '%k%' THEN 'High Poster (>1K posts)'
        WHEN CAST(posts AS DECIMAL) >= 5000 THEN 'Very Active (5K+ posts)'
        WHEN CAST(posts AS DECIMAL) >= 1000 THEN 'Active (1K-5K posts)'
        ELSE 'Less Active (<1K posts)'
    END as posting_activity,
    COUNT(*) as influencer_count,
    ROUND(AVG(influence_score), 2) as avg_influence_score,
    ROUND(AVG(CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL)), 3) as avg_engagement_rate,
    ROUND(AVG(
        CASE 
            WHEN followers LIKE '%b%' THEN CAST(REPLACE(followers, 'b', '') AS DECIMAL) * 1000
            WHEN followers LIKE '%m%' THEN CAST(REPLACE(followers, 'm', '') AS DECIMAL)
            ELSE CAST(followers AS DECIMAL) / 1000000
        END
    ), 1) as avg_followers_millions
FROM influencers
GROUP BY posting_activity
ORDER BY 
    CASE posting_activity
        WHEN 'Very Active (5K+ posts)' THEN 1
        WHEN 'Active (1K-5K posts)' THEN 2
        WHEN 'High Poster (>1K posts)' THEN 3
        ELSE 4
    END;

-- =============================================
-- 6. LIKES ANALYSIS
-- =============================================

-- 6.1 Average likes performance
SELECT 
    CASE 
        WHEN avg_likes LIKE '%m%' AND CAST(REPLACE(avg_likes, 'm', '') AS DECIMAL) >= 5 THEN 'Very High (>5M)'
        WHEN avg_likes LIKE '%m%' THEN 'High (1-5M)'
        WHEN avg_likes LIKE '%k%' AND CAST(REPLACE(avg_likes, 'k', '') AS DECIMAL) >= 500 THEN 'Medium (500K-1M)'
        ELSE 'Lower (<500K)'
    END as likes_category,
    COUNT(*) as influencer_count,
    ROUND(AVG(influence_score), 2) as avg_influence_score,
    ROUND(AVG(CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL)), 3) as avg_engagement_rate
FROM influencers
GROUP BY likes_category
ORDER BY 
    CASE likes_category
        WHEN 'Very High (>5M)' THEN 1
        WHEN 'High (1-5M)' THEN 2
        WHEN 'Medium (500K-1M)' THEN 3
        ELSE 4
    END;

-- =============================================
-- 7. TOP PERFORMERS IN EACH CATEGORY
-- =============================================

-- 7.1 Top 5 by influence score
SELECT 
    RANK() OVER (ORDER BY influence_score DESC) as overall_rank,
    channel_info,
    influence_score,
    followers,
    sixty_day_eng_rate,
    country
FROM influencers
ORDER BY influence_score DESC
LIMIT 5;

-- 7.2 Top 5 by engagement rate
SELECT 
    RANK() OVER (ORDER BY CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL) DESC) as engagement_rank,
    channel_info,
    CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL) as engagement_rate,
    followers,
    influence_score,
    country
FROM influencers
WHERE sixty_day_eng_rate != 'NaN'
ORDER BY CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL) DESC
LIMIT 5;

-- 7.3 Top 5 by followers
SELECT 
    RANK() OVER (ORDER BY 
        CASE 
            WHEN followers LIKE '%b%' THEN CAST(REPLACE(followers, 'b', '') AS DECIMAL) * 1000
            WHEN followers LIKE '%m%' THEN CAST(REPLACE(followers, 'm', '') AS DECIMAL)
            ELSE CAST(followers AS DECIMAL) / 1000000
        END DESC
    ) as follower_rank,
    channel_info,
    followers,
    influence_score,
    sixty_day_eng_rate,
    country
FROM influencers
ORDER BY 
    CASE 
        WHEN followers LIKE '%b%' THEN CAST(REPLACE(followers, 'b', '') AS DECIMAL) * 1000
        WHEN followers LIKE '%m%' THEN CAST(REPLACE(followers, 'm', '') AS DECIMAL)
        ELSE CAST(followers AS DECIMAL) / 1000000
    END DESC
LIMIT 5;

-- =============================================
-- 8. TREND ANALYSIS
-- =============================================

-- 8.1 New post performance vs average
SELECT 
    channel_info,
    avg_likes as historical_avg_likes,
    new_post_avg_like as recent_post_likes,
    CASE 
        WHEN new_post_avg_like LIKE '%k%' AND avg_likes LIKE '%k%' THEN
            ROUND((CAST(REPLACE(new_post_avg_like, 'k', '') AS DECIMAL) / 
                   CAST(REPLACE(avg_likes, 'k', '') AS DECIMAL) - 1) * 100, 1)
        WHEN new_post_avg_like LIKE '%m%' AND avg_likes LIKE '%m%' THEN
            ROUND((CAST(REPLACE(new_post_avg_like, 'm', '') AS DECIMAL) / 
                   CAST(REPLACE(avg_likes, 'm', '') AS DECIMAL) - 1) * 100, 1)
        ELSE 0
    END as growth_percentage,
    influence_score,
    country
FROM influencers
WHERE new_post_avg_like IS NOT NULL AND avg_likes IS NOT NULL
ORDER BY 
    CASE 
        WHEN new_post_avg_like LIKE '%k%' AND avg_likes LIKE '%k%' THEN
            (CAST(REPLACE(new_post_avg_like, 'k', '') AS DECIMAL) / 
             CAST(REPLACE(avg_likes, 'k', '') AS DECIMAL) - 1) * 100
        WHEN new_post_avg_like LIKE '%m%' AND avg_likes LIKE '%m%' THEN
            (CAST(REPLACE(new_post_avg_like, 'm', '') AS DECIMAL) / 
             CAST(REPLACE(avg_likes, 'm', '') AS DECIMAL) - 1) * 100
        ELSE 0
    END DESC
LIMIT 10;

-- =============================================
-- 9. MARKET SEGMENTATION
-- =============================================

-- 9.1 Segment influencers for marketing campaigns
SELECT 
    CASE 
        -- Mega influencers with good engagement
        WHEN (followers LIKE '%b%' OR 
              (followers LIKE '%m%' AND CAST(REPLACE(followers, 'm', '') AS DECIMAL) >= 100))
             AND CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL) >= 1 
             THEN 'Brand Ambassadors'
        
        -- Large influencers with high engagement
        WHEN followers LIKE '%m%' AND CAST(REPLACE(followers, 'm', '') AS DECIMAL) >= 50
             AND CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL) >= 1.5 
             THEN 'Premium Influencers'
        
        -- Medium influencers with very high engagement
        WHEN followers LIKE '%m%' AND CAST(REPLACE(followers, 'm', '') AS DECIMAL) >= 10
             AND CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL) >= 2 
             THEN 'High-Value Micro'
        
        -- Small influencers with exceptional engagement
        WHEN (followers LIKE '%m%' AND CAST(REPLACE(followers, 'm', '') AS DECIMAL) < 10)
             AND CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL) >= 3 
             THEN 'Niche Experts'
        
        ELSE 'Mass Followers'
    END as marketing_segment,
    COUNT(*) as influencer_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM influencers), 1) as segment_percentage,
    ROUND(AVG(influence_score), 2) as avg_influence_score,
    ROUND(AVG(
        CASE 
            WHEN followers LIKE '%b%' THEN CAST(REPLACE(followers, 'b', '') AS DECIMAL) * 1000
            WHEN followers LIKE '%m%' THEN CAST(REPLACE(followers, 'm', '') AS DECIMAL)
            ELSE CAST(followers AS DECIMAL) / 1000000
        END
    ), 1) as avg_followers_millions,
    ROUND(AVG(CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL)), 2) as avg_engagement_rate
FROM influencers
GROUP BY marketing_segment
ORDER BY avg_engagement_rate DESC;

-- =============================================
-- 10. CORRELATION ANALYSIS
-- =============================================

-- 10.1 Manual correlation calculation (SQL doesn't have CORR function in all versions)
SELECT 
    'Influence Score vs Followers' as correlation_pair,
    ROUND(
        (SUM((influence_score - avg_score) * (followers_num - avg_followers)) / 
         (SQRT(SUM(POWER(influence_score - avg_score, 2)) * 
               SUM(POWER(followers_num - avg_followers, 2))))), 3
    ) as correlation_coefficient
FROM influencers,
    (SELECT 
        AVG(influence_score) as avg_score,
        AVG(
            CASE 
                WHEN followers LIKE '%b%' THEN CAST(REPLACE(followers, 'b', '') AS DECIMAL) * 1000
                WHEN followers LIKE '%m%' THEN CAST(REPLACE(followers, 'm', '') AS DECIMAL)
                ELSE CAST(followers AS DECIMAL) / 1000000
            END
        ) as avg_followers
     FROM influencers) as averages,
    (SELECT 
        influence_score,
        CASE 
            WHEN followers LIKE '%b%' THEN CAST(REPLACE(followers, 'b', '') AS DECIMAL) * 1000
            WHEN followers LIKE '%m%' THEN CAST(REPLACE(followers, 'm', '') AS DECIMAL)
            ELSE CAST(followers AS DECIMAL) / 1000000
        END as followers_num
     FROM influencers) as numeric_data;

-- =============================================
-- 11. BUSINESS RECOMMENDATIONS
-- =============================================

-- 11.1 Best value influencers (high engagement, reasonable followers)
SELECT 
    rank,
    channel_info,
    country,
    followers,
    sixty_day_eng_rate as engagement_rate,
    influence_score,
    -- Engagement per million followers (proxy for value)
    ROUND(
        (CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL) * 
         CASE 
            WHEN followers LIKE '%b%' THEN CAST(REPLACE(followers, 'b', '') AS DECIMAL) * 1000
            WHEN followers LIKE '%m%' THEN CAST(REPLACE(followers, 'm', '') AS DECIMAL)
            ELSE CAST(followers AS DECIMAL) / 1000000
         END) / 100, 2
    ) as engagement_value_score,
    CASE 
        WHEN CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL) >= 3 
             AND (followers LIKE '%m%' AND CAST(REPLACE(followers, 'm', '') AS DECIMAL) BETWEEN 10 AND 50)
             THEN 'High ROI Target'
        WHEN CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL) >= 2 
             AND (followers LIKE '%m%' AND CAST(REPLACE(followers, 'm', '') AS DECIMAL) BETWEEN 50 AND 100)
             THEN 'Medium ROI Target'
        ELSE 'Standard'
    END as recommendation
FROM influencers
WHERE sixty_day_eng_rate IS NOT NULL AND followers IS NOT NULL
ORDER BY engagement_value_score DESC
LIMIT 15;

-- =============================================
-- 12. GROWTH ANALYSIS
-- =============================================

-- 12.1 Influencers showing growth momentum
SELECT 
    channel_info,
    country,
    followers,
    influence_score,
    sixty_day_eng_rate as current_engagement,
    avg_likes as historical_avg_likes,
    new_post_avg_like as recent_likes,
    CASE 
        WHEN new_post_avg_like LIKE '%k%' AND avg_likes LIKE '%k%' THEN
            CASE 
                WHEN CAST(REPLACE(new_post_avg_like, 'k', '') AS DECIMAL) > 
                     CAST(REPLACE(avg_likes, 'k', '') AS DECIMAL) * 1.2 THEN 'Rapid Growth'
                WHEN CAST(REPLACE(new_post_avg_like, 'k', '') AS DECIMAL) > 
                     CAST(REPLACE(avg_likes, 'k', '') AS DECIMAL) * 1.1 THEN 'Steady Growth'
                ELSE 'Stable'
            END
        WHEN new_post_avg_like LIKE '%m%' AND avg_likes LIKE '%m%' THEN
            CASE 
                WHEN CAST(REPLACE(new_post_avg_like, 'm', '') AS DECIMAL) > 
                     CAST(REPLACE(avg_likes, 'm', '') AS DECIMAL) * 1.2 THEN 'Rapid Growth'
                WHEN CAST(REPLACE(new_post_avg_like, 'm', '') AS DECIMAL) > 
                     CAST(REPLACE(avg_likes, 'm', '') AS DECIMAL) * 1.1 THEN 'Steady Growth'
                ELSE 'Stable'
            END
        ELSE 'Cannot Determine'
    END as growth_status
FROM influencers
WHERE new_post_avg_like IS NOT NULL 
    AND avg_likes IS NOT NULL
    AND (
        (new_post_avg_like LIKE '%k%' AND avg_likes LIKE '%k%') OR
        (new_post_avg_like LIKE '%m%' AND avg_likes LIKE '%m%')
    )
ORDER BY 
    CASE 
        WHEN new_post_avg_like LIKE '%k%' AND avg_likes LIKE '%k%' THEN
            CAST(REPLACE(new_post_avg_like, 'k', '') AS DECIMAL) / 
            CAST(REPLACE(avg_likes, 'k', '') AS DECIMAL)
        WHEN new_post_avg_like LIKE '%m%' AND avg_likes LIKE '%m%' THEN
            CAST(REPLACE(new_post_avg_like, 'm', '') AS DECIMAL) / 
            CAST(REPLACE(avg_likes, 'm', '') AS DECIMAL)
        ELSE 1
    END DESC
LIMIT 10;