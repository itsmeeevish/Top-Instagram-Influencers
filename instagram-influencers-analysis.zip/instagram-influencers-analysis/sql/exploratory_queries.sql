

-- 1. Basic Dataset Overview
SELECT COUNT(*) as total_influencers FROM influencers;
SELECT * FROM influencers LIMIT 10;

-- 2. Country-wise Distribution (Page 81)
SELECT 
    country,
    COUNT(*) as influencer_count,
    AVG(CAST(REPLACE(REPLACE(followers, 'm', ''), 'b', '') AS DECIMAL)) as avg_followers_millions
FROM influencers
GROUP BY country
ORDER BY influencer_count DESC;

-- 3. Top Influencers by Influence Score (Page 82)
SELECT 
    rank,
    channel_info,
    influence_score,
    followers,
    sixty_day_eng_rate
FROM influencers
ORDER BY influence_score DESC
LIMIT 10;

-- 4. Engagement Rate Analysis (Page 82-83)
SELECT 
    AVG(CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL)) as avg_engagement_rate,
    MAX(CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL)) as max_engagement_rate,
    MIN(CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL)) as min_engagement_rate
FROM influencers;

-- 5. High Engagement, Low Followers (Page 83)
SELECT 
    channel_info,
    followers,
    sixty_day_eng_rate,
    country
FROM influencers
WHERE CAST(REPLACE(REPLACE(followers, 'm', ''), 'b', '') AS DECIMAL) < 100  -- Less than 100M
    AND CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL) > 3
ORDER BY CAST(REPLACE(sixty_day_eng_rate, '%', '') AS DECIMAL) DESC;

-- 6. Growth Potential Analysis (Page 85)
SELECT 
    channel_info,
    avg_likes,
    new_post_avg_like,
    ROUND(
        (CAST(REPLACE(new_post_avg_like, 'k', '000') AS DECIMAL) / 
         CAST(REPLACE(avg_likes, 'k', '000') AS DECIMAL) - 1) * 100, 2
    ) as growth_percentage
FROM influencers
WHERE new_post_avg_like LIKE '%k%' AND avg_likes LIKE '%k%'
ORDER BY growth_percentage DESC;

-- 7. Country-wise Average Influence Score (Page 86)
SELECT 
    country,
    AVG(influence_score) as avg_influence_score,
    COUNT(*) as influencer_count
FROM influencers
GROUP BY country
HAVING COUNT(*) >= 2
ORDER BY avg_influence_score DESC;