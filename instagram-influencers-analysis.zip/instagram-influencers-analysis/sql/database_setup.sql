
CREATE DATABASE IF NOT EXISTS InstagramInfluencers;
USE InstagramInfluencers;

CREATE TABLE influencers (
    rank INT PRIMARY KEY,
    channel_info VARCHAR(100),
    influence_score INT,
    posts VARCHAR(20),
    followers VARCHAR(20),
    avg_likes VARCHAR(20),
    sixty_day_eng_rate VARCHAR(10),
    new_post_avg_like VARCHAR(20),
    total_likes VARCHAR(20),
    country VARCHAR(50)
);

-- EXACT DATA FROM DOCUMENT PAGES 15-19
INSERT INTO influencers VALUES
(1, 'cristiano', 92, '3300', '475.8m', '8.7m', '1.39%', '6.5m', '2.900000e+10', 'Spain'),
(2, 'kyliejenner', 91, '6900', '366.2m', '8.3m', '1.62%', '5.9m', '5.740000e+10', 'United States'),
(3, 'leomessi', 90, '890', '357.3m', '6.8m', '1.24%', '4.4m', '6.000000e+09', 'Argentina'),
(4, 'selenagomez', 93, '1800', '342.7m', '6.2m', '0.97%', '3.3m', '1.150000e+10', 'United States'),
(5, 'therock', 91, '6800', '334.1m', '1.9m', '0.20%', '665.3k', '1.250000e+10', 'United States'),
(6, 'kimkardashian', 91, '5600', '329.2m', '3.5m', '0.88%', '2.9m', '1.990000e+10', 'United States'),
(7, 'arianagrande', 92, '5000', '327.7m', '3.7m', '1.20%', '3.9m', '1.840000e+10', 'United States'),
(8, 'beyonce', 92, '2000', '272.8m', '3.6m', '0.76%', '2.0m', '7.400000e+09', 'United States'),
(9, 'khloekardashian', 89, '4100', '268.3m', '2.4m', '0.35%', '926.9k', '9.800000e+09', 'United States'),
(10, 'justinbieber', 91, '7400', '254.5m', '1.9m', '0.59%', '1.5m', '1.390000e+10', 'Canada'),
(11, 'kendalljenner', 90, '6600', '254.0m', '5.5m', '2.04%', '5.1m', '3.700000e+09', 'United States'),
(12, 'natgeo', 91, '1000k', '237.0m', '302.2k', '0.07%', '159.3k', '3.000000e+09', 'United States'),
(13, 'nike', 90, '950k', '234.1m', '329.0k', '0.08%', '181.8k', '313.6m', 'United States'),
(14, 'taylorswift', 91, '530k', '222.2m', '2.4m', '1.01%', '2.3m', '1.300000e+09', 'United States'),
(15, 'jlo', 89, '320k', '220.4m', '1.7m', '0.62%', '1.4m', '5.300000e+09', 'United States'),
(16, 'virat.kohli', 87, '140k', '211.8m', '3.5m', '0.96%', '2.0m', '4.900000e+09', 'India'),
(17, 'nickiminaj', 90, '640k', '201.6m', '2.1m', '0.53%', '1.0m', '13.5b', 'United States'),
(18, 'kourtneykardash', 89, '440k', '195.2m', '1.8m', '0.67%', '1.3m', '7.700000e+09', 'United States'),
(19, 'mileycyrus', 89, '120k', '181.5m', '1.3m', '0.51%', '913.6k', '1.600000e+09', 'United States'),
(20, 'neymarjr', 90, '530k', '177.1m', '2.7m', '1.09%', '1.9m', '14.1b', 'Brazil');

-- Add more data as needed ...